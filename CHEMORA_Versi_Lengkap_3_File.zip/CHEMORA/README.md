# CHEMORA — Website Pembelajaran Kimia

CHEMORA adalah website pembelajaran kimia sederhana dan interaktif untuk siswa SMA/SMK.

## Struktur folder

Pastikan ketiga file ini berada di dalam folder yang sama:

```text
CHEMORA/
├── index.html
├── style.css
└── script.js
```

## Menjalankan di komputer

1. Unduh dan ekstrak ZIP.
2. Buka folder `CHEMORA_Lengkap`.
3. Klik dua kali `index.html` atau buka dengan browser.
4. Pastikan `style.css` dan `script.js` tetap berada satu folder dengan `index.html`.

## Memublikasikan melalui GitHub Pages

1. Buat repository baru di GitHub, misalnya bernama `chemora`.
2. Unggah **isi folder** ini ke bagian paling luar (root) repository. Jangan sampai file berada di dalam folder tambahan.
3. Pastikan `index.html`, `style.css`, dan `script.js` terlihat langsung di halaman utama repository.
4. Buka **Settings → Pages**.
5. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
7. Tunggu proses publikasi selesai. Alamat situs biasanya berbentuk `https://NAMA-USERNAME.github.io/chemora/`.

## Bagian yang bisa dikembangkan

- Tambahkan materi sesuai kurikulum sekolah.
- Tambahkan gambar atau video pembelajaran milik sendiri atau yang memiliki izin penggunaan.
- Tambahkan lebih banyak soal ke array `questions` di `script.js`.
- Ubah warna, ukuran, dan tata letak melalui `style.css`.

Catatan: Kalkulator mol menggunakan rumus dasar `n = m / Mr`. Kuis ini untuk latihan pengenalan dan bukan pengganti pembelajaran atau arahan guru.
